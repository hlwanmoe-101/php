<?php require_once "core/auth.php"?>
<?php include "template/header.php"?>

<h2>This is Dashboard</h2>
<?php //print_r($_SESSION['user']) ?>
<?php //echo $url; ?><!--assets/img/--><?php //echo $_SESSION['user']['photo']?>
<?php include "template/footer.php"?>
