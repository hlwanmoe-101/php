<script src="<?php echo $url; ?>assets/vendor/jquery-3.6.0.min.js"></script>
<script src="<?php echo $url; ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo $url; ?>assets/js/app.js"></script>
</body>
</html>